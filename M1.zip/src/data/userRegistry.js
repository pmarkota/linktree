// In-memory user registry for the POC
const userRegistry = {
  dnshko: "Dinesh",
  dinesh: "Dinesh", // Add both variations if needed
};

// Export to allow modification in the controller
module.exports = userRegistry;
